# Maintenance Tracker — Deployment Guide

## What You're Setting Up

A web app that you and your team can open on any phone or computer. It tracks filler downtime with live timers, logs parts, and generates shift reports. All data is stored in a real database.

**Final result:** A URL like `maintenance-tracker-production.up.railway.app` that everyone bookmarks or adds to their home screen.

---

## Step 1: Create a GitHub Account (skip if you have one)

1. Go to **https://github.com** on your phone or computer
2. Tap **Sign up**
3. Enter your email, pick a password, choose a username
4. Verify your email — done

---

## Step 2: Upload the Project to GitHub

1. Log into **https://github.com**
2. Click the **+** icon in the top right → **New repository**
3. Name it: `maintenance-tracker`
4. Leave it set to **Public**
5. Check the box **"Add a README file"**
6. Click **Create repository**

Now you need to upload all the project files:

7. On your new repo page, click **"Add file"** → **"Upload files"**
8. Drag and drop ALL the files from the project zip I gave you:
   - `server.js`
   - `database.js`
   - `package.json`
   - `railway.toml`
   - `.gitignore`
   - The `public` folder (with `index.html`, `manifest.json`, `icon.svg`)
9. Scroll down and click **"Commit changes"**

**Important:** Make sure the `public` folder is uploaded as a folder, not just the files inside it. If GitHub flattens it, create the folder first by clicking "Add file" → "Create new file" and typing `public/index.html` as the filename, then paste the contents.

---

## Step 3: Deploy on Railway (Free Tier)

1. Go to **https://railway.app**
2. Click **"Login"** → **"Login with GitHub"** (use the account from Step 1)
3. Authorize Railway to access your GitHub
4. On the Railway dashboard, click **"New Project"**
5. Click **"Deploy from GitHub repo"**
6. Select your **maintenance-tracker** repository
7. Railway will automatically detect it's a Node.js app and start building

### Configure Storage (so your data survives restarts):

8. Click on your service in Railway
9. Go to the **"Volumes"** tab
10. Click **"Add Volume"**
11. Mount path: `/app/data`
12. Click **"Add"**

### Add Environment Variable:

13. Go to the **"Variables"** tab
14. Click **"Add Variable"**
15. Name: `DB_PATH` — Value: `/app/data/tracker.db`
16. Click **"Add"**

### Get Your URL:

17. Go to the **"Settings"** tab
18. Under **"Networking"** → **"Public Networking"**
19. Click **"Generate Domain"**
20. Railway gives you a URL like: `maintenance-tracker-production.up.railway.app`

**That's it! Your app is live.**

---

## Step 4: Add to Your Phone's Home Screen

### iPhone:
1. Open **Safari** (must be Safari, not Chrome)
2. Go to your Railway URL
3. Tap the **Share button** (square with arrow at the bottom)
4. Scroll down → tap **"Add to Home Screen"**
5. Name it "Maint Tracker" → tap **Add**

### Android:
1. Open **Chrome**
2. Go to your Railway URL
3. Tap the **three-dot menu** (top right)
4. Tap **"Add to Home Screen"** or **"Install App"**
5. Confirm → tap **Add**

The app will now launch full-screen like a regular app.

---

## Step 5: Share with Your Team

Just send the Railway URL to your coworkers. They can:
- Open it in any browser on their phone
- Add it to their home screen using the same steps above
- Everyone shares the same data — events, parts, timers

---

## Troubleshooting

**App shows an error when loading:**
- Go to Railway dashboard → click your service → check the "Deployments" tab for error logs
- Most likely a missing file — double-check all files are uploaded to GitHub

**Data disappeared after redeploy:**
- Make sure you added the Volume (Step 3, #8-11) and the DB_PATH variable (Step 3, #13-16)

**Timer started but I closed the app:**
- No problem — timers are stored in the database. Open the app again and the timer will still be running from the original start time

**Want to update the app:**
- Edit files on GitHub → Railway automatically redeploys

---

## Cost

Railway's free tier includes:
- 500 hours of runtime per month (plenty for one app running 24/7 for ~20 days)
- If you need it running all month, the Hobby plan is $5/month with no limits
- Your data is backed up in the volume

---

## Files in This Project

```
maintenance-tracker/
├── server.js          ← The backend (API + serves the frontend)
├── database.js        ← Database setup (SQLite)
├── package.json       ← Dependencies
├── railway.toml       ← Railway deployment config
├── .gitignore         ← Tells git to ignore data files
└── public/
    ├── index.html     ← The entire frontend app
    ├── manifest.json  ← Makes it installable on phones
    └── icon.svg       ← Home screen icon
```
